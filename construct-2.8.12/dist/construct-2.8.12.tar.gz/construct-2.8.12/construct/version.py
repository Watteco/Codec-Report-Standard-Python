version = (2, 8, 12)
version_string = "2.8.12"
release_date = "2017.04.25"
